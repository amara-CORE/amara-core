# Amara CORE
Autonómny AI systém na generovanie zisku.