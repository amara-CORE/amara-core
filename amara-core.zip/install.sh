#!/bin/bash
echo 'Inštalujem Amaru...'
# Tu by boli príkazy na inštaláciu závislostí atď.